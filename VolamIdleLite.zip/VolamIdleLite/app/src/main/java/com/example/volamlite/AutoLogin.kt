package com.example.volamlite

import org.json.JSONObject

/**
 * Script tự đăng nhập chạy định kỳ trong trang game.
 * Chỉ điền ô tài khoản/mật khẩu đã lưu và bấm nút - KHÔNG ghi lại phím gõ, KHÔNG gửi dữ liệu ra ngoài.
 * Trả về chuỗi trạng thái: LOGIN_SUBMITTED, FILLED, START_CLICKED, IDLE.
 */
object AutoLogin {
    private const val JS = """
(function(U, P) {
  function norm(s){return (s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/đ/g,'d').trim();}
  function vis(e){var r=e.getBoundingClientRect();var s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none';}
  function setVal(el,v){
    if(el.value===v) return;
    var proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto,'value').set.call(el,v);
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
  }
  function click(el){
    ['pointerdown','mousedown','pointerup','mouseup','click'].forEach(function(t){
      el.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window}));
    });
  }
  function findBtn(words){
    var els=document.querySelectorAll('button,[role="button"],a,div,span,li');
    for(var i=0;i<els.length;i++){
      var e=els[i]; if(!vis(e)||e.disabled) continue;
      var t=norm(e.textContent); if(t.length>30) continue;
      if(words.indexOf(t)>=0) return e;
    }
    return null;
  }
  var inputs=Array.prototype.filter.call(
    document.querySelectorAll('input:not([type=hidden]):not([type=checkbox]):not([type=radio]),textarea'),
    function(e){return vis(e)&&!e.disabled&&!e.readOnly;});
  var pw=inputs.filter(function(e){return e.type==='password';})[0];
  if(pw && U && P){
    var idx=inputs.indexOf(pw);
    var user=idx>0?inputs[idx-1]:null;
    if(user){ setVal(user,U); }
    setVal(pw,P);
    var now=Date.now();
    if(now-(window.__lastLogin||0)>6000){
      var b=findBtn(['dang nhap','login','xac nhan','xac dinh','vao game']);
      if(b){ window.__lastLogin=now; click(b); return 'LOGIN_SUBMITTED'; }
    }
    return 'FILLED';
  }
  var s=findBtn(['bat dau tro choi','bat dau','vao game','vao giang ho']);
  if(s){ click(s); return 'START_CLICKED'; }
  return 'IDLE';
})(__USER__, __PASS__)
"""

    fun build(user: String, pass: String): String =
        JS.replace("__USER__", JSONObject.quote(user)).replace("__PASS__", JSONObject.quote(pass))
}
