package com.example.volamlite

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    companion object { const val GAME_URL = "https://volamidle.pages.dev" }

    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var autoBtn: Button
    private lateinit var store: Store
    private val handler = Handler(Looper.getMainLooper())
    private var loop: Runnable? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#202020"))
            setPadding(16, 8, 16, 8)
        }
        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; text = "Sẵn sàng" }
        bar.addView(status, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; textSize = 11f; isAllCaps = false; setOnClickListener { f() }
        }.also { bar.addView(it) }
        btn("Tài khoản") { showAccountDialog() }
        btn("Tải lại") { web.reload() }
        autoBtn = btn("") { store.auto = !store.auto; refreshAutoLabel() }
        refreshAutoLabel()

        web = WebView(this)
        root.addView(bar)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { status.text = "Đã tải trang" }
            override fun onReceivedError(v: WebView?, c: Int, d: String?, u: String?) {
                status.text = "Lỗi mạng, thử lại sau 10 giây…"
                handler.postDelayed({ web.loadUrl(GAME_URL) }, 10_000)
            }
        }
        web.loadUrl(GAME_URL)
        startService(Intent(this, KeepAliveService::class.java))
    }

    private fun refreshAutoLabel() { autoBtn.text = if (store.auto) "Auto: BẬT" else "Auto: TẮT" }

    private fun showAccountDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        val u = EditText(this).apply { hint = "Tài khoản"; setText(store.user); setSingleLine() }
        val p = EditText(this).apply {
            hint = "Mật khẩu"; setText(store.pass); setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(u); box.addView(p)
        AlertDialog.Builder(this)
            .setTitle("Tài khoản đăng nhập")
            .setMessage("Lưu mã hoá trên máy, chỉ dùng để tự điền vào trang game.")
            .setView(box)
            .setPositiveButton("Lưu") { _, _ ->
                store.user = u.text.toString(); store.pass = p.text.toString()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun tick() {
        if (store.auto && store.user.isNotEmpty() && store.pass.isNotEmpty()) {
            web.evaluateJavascript(AutoLogin.build(store.user, store.pass)) { r ->
                status.text = "Auto: " + (r ?: "").trim('"')
            }
        }
        loop = Runnable { tick() }.also { handler.postDelayed(it, 3000) }
    }

    override fun onResume() { super.onResume(); web.onResume(); loop?.let(handler::removeCallbacks); tick() }
    override fun onPause() {
        // Không gọi web.onPause() để game vẫn chạy khi thoát ra màn hình chính.
        super.onPause()
    }
    override fun onDestroy() {
        loop?.let(handler::removeCallbacks)
        web.destroy()
        super.onDestroy()
    }
    @Deprecated("") override fun onBackPressed() { moveTaskToBack(true) }
}
